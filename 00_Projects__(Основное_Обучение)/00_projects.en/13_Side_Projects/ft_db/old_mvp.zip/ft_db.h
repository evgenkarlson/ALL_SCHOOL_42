/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_db.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto <anieto@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/04/30 22:04:06 by anieto            #+#    #+#             */
/*   Updated: 2017/04/30 22:04:08 by anieto           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_DB_H
# define FT_DB_H

# include <stdio.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include <unistd.h>
# include <string.h>
# include <stdlib.h>

typedef struct		s_person_rec
{
	unsigned int	key;
	char			fname[16];
	char			lname[16];
	unsigned int	age;
}					t_person_rec;

int					open_record(char *filename);
int					insert_record(int fd, t_person_rec *rec);
int					print_record(int fd, t_person_rec *rec, unsigned int key);
int					update_record(int fd, t_person_rec *rec_new);
int					delete_record(int fd, unsigned int key);

#endif
