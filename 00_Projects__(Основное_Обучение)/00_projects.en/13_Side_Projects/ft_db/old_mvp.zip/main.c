/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto <anieto@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/04/30 22:04:16 by anieto            #+#    #+#             */
/*   Updated: 2017/04/30 22:04:22 by anieto           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_db.h"

int	main(int argc, char const *argv[])
{
	int				fd;
	t_person_rec	rec;


	if (argc > 1)
	{
		if (argc == 6 && !strcmp(argv[1], "create"))
		{
			fd = open_record("data1");
			rec.key = atoi(argv[2]);
			strcpy(rec.fname, argv[3]);
			strcpy(rec.lname, argv[4]);
			rec.age = atoi(argv[5]);
			insert_record(fd, &rec);
			close(fd);
		}
		else if (argc == 3 && !strcmp(argv[1], "read"))
		{
			fd = open_record("data1");
			print_record(fd, &rec, atoi(argv[2]));
			printf("Key = %d\nFirst = %s\n", rec.key, rec.fname);
			printf("Last = %s\nAge = %d\n", rec.lname, rec.age);
			close(fd);
		}
		else if (argc == 6 && !strcmp(argv[1], "update"))
		{
			fd = open_record("data1");
			rec.key = atoi(argv[2]);
			strcpy(rec.fname, argv[3]);
			strcpy(rec.lname, argv[4]);
			rec.age = atoi(argv[5]);
			update_record(fd, &rec);
			printf("Record updated\n");
			close(fd);
			system("mv data1 data_backup");
			system("mv data2 data1");
		}
		else if (argc == 3 && !strcmp(argv[1], "delete"))
		{
			fd = open_record("data1");
			delete_record(fd, atoi(argv[2]));
			printf("Record Deleted\n");
			close(fd);
			system("mv data1 data_backup");
			system("mv data2 data1");
		}
		else
		{
			printf("usage: ./ft_db [COMMAND] [KEY]\n");
			printf("command :\ncreate [KEY] [FIRST_NAME] [LAST_NAME] [AGE]\n");
			printf("read [KEY]\nupdate [KEY] [FIRST_NAME] [LAST_NAME] [AGE]\n");
			printf("delete [KEY]\n");
		}
	}
	return (0);
}
