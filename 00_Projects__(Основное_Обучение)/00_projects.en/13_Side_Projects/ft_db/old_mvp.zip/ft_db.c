/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_db.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anieto <anieto@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/04/30 19:52:37 by anieto            #+#    #+#             */
/*   Updated: 2017/04/30 22:00:36 by anieto           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_db.h"

int					open_record(char *filename)
{
	int				fd;

	fd = open(filename, O_CREAT | O_RDWR | O_APPEND, 0777);
	if (fd == -1)
		perror("open_record");
	return (fd);
}

void				close_record(int fd)
{
	close(fd);
}

int					insert_record(int fd, t_person_rec *rec)
{
	int				ret;

	ret = write(fd, rec, sizeof(t_person_rec));
	return (ret);
}

int					print_record(int fd, t_person_rec *rec, unsigned int key)
{
	int				ret;

	while ((ret = read(fd, rec, sizeof(t_person_rec))) != -1)
	{
		if (ret == 0)
		{
			memset(rec, 0, sizeof(t_person_rec));
			//break ;
			return (ret);
		}
		else if (key == rec->key)
			return (ret);
	}
	memset(rec, 0, sizeof(t_person_rec));
	return (ret);
}

int					update_record(int fd, t_person_rec *rec_new)
{
	int				ret;
	t_person_rec	rec;
	int fd2;
	int ret2;

	fd2 = open("data2", O_CREAT | O_RDWR | O_APPEND, 0777);
	if (fd2 < 0)
		perror("opening FIlE");
	while ((ret = read(fd, &rec, sizeof(t_person_rec))) != -1)
	{
		if (ret == 0)
		{
			return (ret);
		}
		else if (rec_new->key != rec.key)
		{
			ret2 = write(fd2, &rec, sizeof(t_person_rec));
			if (ret2 < 0)
				perror("Writing to file");
		}
		else if (rec_new->key == rec.key)
		{
			ret2 = write(fd2, rec_new, sizeof(t_person_rec));
			if (ret2 < 0)
				perror("Writing to file");
		}
	}
	close(fd2);
	return (ret);
}

int					delete_record(int fd, unsigned int key)
{
	int				ret;
	t_person_rec	rec;
	int fd2;
	int ret2;

	fd2 = open("data2", O_CREAT | O_RDWR | O_APPEND, 0777);
	if (fd2 < 0)
		perror("opening FIlE");
	while ((ret = read(fd, &rec, sizeof(t_person_rec))) != -1)
	{
		if (ret == 0)
		{
			return (ret);
		}
		else if (key != rec.key)
		{

			ret2 = write(fd2, &rec, sizeof(t_person_rec));
			if (ret2 < 0)
				perror("Writing to file");
		}
	}
	close(fd2);
	return (ret);
}
